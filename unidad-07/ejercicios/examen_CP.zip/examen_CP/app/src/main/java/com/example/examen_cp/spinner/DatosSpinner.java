package com.example.examen_cp.spinner;

public class DatosSpinner {
    private final int avatar;
    public DatosSpinner(int avatar) {
        this.avatar = avatar;
    }
    public int getAvatar() {
        return avatar;
    }
}
